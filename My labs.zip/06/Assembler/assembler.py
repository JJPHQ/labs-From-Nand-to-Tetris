# written in python
# Implememtation of Assembler of course-
# From Nand to Tetris 

import sys,os
from pathlib import Path

TopFileFold = os.getcwd()+'/..'

Targetfile = sys.argv[1].replace(" ","")
symbolLess     = sys.argv[2]
#print('symbolLess: '+symbolLess)

file_name     =  Path(TopFileFold+'/'+Targetfile+'/'+Targetfile.capitalize()+'.asm') 
tgt_bin_file  =  TopFileFold+'/'+Targetfile+'/'+Targetfile.capitalize() + '.hack'
Lfile_name    =  Path(TopFileFold+'/'+Targetfile+'/'+Targetfile.capitalize()+'L'+'.asm')
Ltgt_bin_file =  TopFileFold+'/'+Targetfile+'/'+Targetfile.capitalize()+'L' + '.hack'


if(symbolLess != 1):
    #print('file_name: \n\t')
    print(file_name)
    print('tgt_bin_name: \n\t')
    print('tgt_bin_name: '+tgt_bin_file)
else:
    #print('Lfile_name: \n\t')
    print(Lfile_name)
    print('tgt_bin_name: \n\t')
    print(Ltgt_bin_file)
 
list1 = [str(x) for x in range(16)] #['1'..'15']
RegDict = dict() # RX -> X
for ele in list1:
    RegDict['R'+ele] = ele
RegDict['SCREEN'] = '16384'
RegDict['KBD']    = '24576'
RegDict['SP']     = '0'
RegDict['LCL']    = '1'
RegDict['ARG']    = '2'
RegDict['THIS']   = '3'
RegDict['THAT']   = '4'

symTable = dict() #create an empty symbol-table
varTable = dict()
 
JumpTable={'null':'000',
           'JGT' :'001',
           'JEQ' :'010',
           'JGE' :'011',
           'JLT' :'100',
           'JNE' :'101',
           'JLE' :'110',
           'JMP' :'111'}
           
CompTable={'0':'101010','1':'111111','-1':'111010','D':'001100',
           'A':'110000','M':'110000','!D':'001101','!A':'110001',
           '!M':'110001','-D':'001111','-A':'110011','-M':'110011',
           'D+1':'011111','A+1':'110111','M+1':'110111','D-1':'001110',
           'A-1':'110010','M-1':'110010','D+A':'000010','D+M':'000010',
           'D-A':'010011','D-M':'010011','A-D':'000111','M-D':'000111',
           'D&A':'000000','D&M':'000000','D|A':'010101','D|M':'010101'}

def commandType(command): # only two conditions:A and C
    if command[0]=='@':
        return 'A_COM'
    else: 
        return 'C_COM'

def symbolA(command):
    #com = command[1:]
    #if(com.isdigit()):
    #   return command[1:]
    #else:
    #    return 
    return command[1:]
    
def dest(command):
    indexEqual = command.find('=')
    if indexEqual == -1:
        return ''
    else:
        return command[0:indexEqual+1]

def destCode(dst):
    d1 = '0' if dst.find('A')==-1 else '1'
    d2 = '0' if dst.find('D')==-1 else '1'
    d3 = '0' if dst.find('M')==-1 else '1'
    d_list = [d1,d2,d3]
    return ''.join(d_list)
    
def jumpCode(jmp):
    
    return JumpTable[jmp] if len(jmp)>0 else JumpTable['null']

def compCode(cmp):
    #print('cmp:'+cmp+'|')
    sym_a='0' if cmp.find('M')==-1 else '1'
    return sym_a+CompTable[cmp]    

def comp(command):
    index1 = command.find('=')
    index2 = command.find(';')
    length=len(command)
    if(index2 == -1):
        return command[index1+1:]
    else:
        return command[index1+1:index2]

def decTobin(decStr):
    DecStr=''
    if decStr.isdigit():
        DecStr = decStr
    else:
        DecStr=RegDict[decStr] if (decStr in RegDict.keys()) else (symTable[decStr] if (decStr in symTable.keys()) 
                               else varTable[decStr])
        
    binStr=bin(int(DecStr))
    ind = binStr.find('b')
    validBin=binStr[ind+1:]
    validBinLen=len(validBin)
    supLen=(15-validBinLen)*'0'
    return supLen+validBin
        

def jump(command):
    index1 = command.find(';')
    if(index1 == -1):
        return ''
    else:
        
        return command[index1+1:]

if file_name.is_file:
    print('This file is found!')

try:
    with open(file_name,'r',encoding = 'utf-8') as f:
    #with open(Lfile_name,'r',encoding = 'utf-8') as f:
        with open(tgt_bin_file,'w',encoding = 'utf-8') as tf:
                    tf.write('')
                    print('Clear primitive contents')
        #while 1:
        VarAddr     = 16;
        #VarCounter  = 0;
        InstCounter = 0;
        
        lines = f.readlines()# 1st traverse for creating symbol table
        
        for line in lines:
            temp = line.replace(' ',"")
            temp = temp.replace('\n',"")
            if temp.find('//')!=-1:
                temp = temp.replace(temp[temp.find('//'):],'')
            #if temp[0:2]=="//": #comment judgement
                #continue
            if not temp:
                continue #empty line  
            
            if temp.find('(') != -1:
                
                ind1 = temp.find('(')
                ind2 = temp.find(')')
                label = temp[ind1+1:ind2]
                #print(label)
                symTable[label] = InstCounter
                continue    
            InstCounter = InstCounter + 1    
        #print(symTable)
        
        # 2nd traverse for parsing,code and assembling
        f.seek(0, 0) # return to the head of file
        
        lines = f.readlines()
        for line in lines:
            temp = line.replace(' ',"")
            temp = temp.replace('\n',"")
            if temp.find('//')!=-1:
                temp = temp.replace(temp[temp.find('//'):],'')
            if not temp:
                continue #empty line 
            
            if temp.find('@') != -1:
                ind1 = temp.find('@')
                var  = temp[ind1+1:]
                #print(var)
                if(var in RegDict.keys() or var.isdigit() or var in symTable.keys() or var in varTable.keys()):
                    continue
                varTable[var] = VarAddr if var not in varTable.keys() else varTable[var]
                VarAddr = VarAddr + 1
                #InstCounter = InstCounter + 1
        print(varTable)
        # 3rd traverse for parsing,code and assembling
        
        f.seek(0, 0) # return to the head of file
        lines = f.readlines() 
        for line in lines:
            temp = line.replace(" ","")
            temp = temp.replace("\n","")
            
            if temp.find('//')!=-1:
                temp = temp.replace(temp[temp.find('//'):],'')
            if not temp:
                continue #empty line 
                
            #print(temp)
            comtype = commandType(temp)
            sym = ''
            dst = ''
            cmp= ''
            jmp = ''
            targetBinCode = ''
            if(comtype=="A_COM"): 
                sym=symbolA(temp)  #sym is now not only a decimal num now, but also possibly a symbol
                targetBinCode='0'+decTobin(sym)
            else:
                if temp.find('(')!=-1:
                    continue
                dst=dest(temp)
                cmp=comp(temp)
                jmp = jump(temp)
                #print('Start debug')
                targetBinCode='111'+compCode(cmp)+destCode(dst)+jumpCode(jmp)
                #print(targetBinCode)
            
            with open(tgt_bin_file,'a+',encoding = 'utf-8') as tf:
            #with open(Ltgt_bin_file,'a+',encoding = 'utf-8') as tf:
                tf.write(targetBinCode+'\n')
                #print(targetBinCode+' has been written')
                
        print('Finishing writting-work')        
    
except:
    print(Lfile_name+'str')
    

'''if temp.find('@') != -1:
    ind1 = temp.find('@')
    var  = temp[ind1+1:].replace('\n','')
    #print(var)
    if(var in RegDict.keys() or var.isdigit()):
        InstCounter = InstCounter + 1
        continue
    
    print(var)
    symTable[var] = VarAddr if var not in symTable.keys() else symTable[var]
    VarAddr = VarAddr + 1
    InstCounter = InstCounter + 1
    continue '''